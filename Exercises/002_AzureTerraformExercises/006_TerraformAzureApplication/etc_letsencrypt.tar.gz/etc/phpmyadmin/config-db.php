<?php
  # !!! dbname is mandatory or login won't work!!!
  #
  $dbuser='sqladmin';
  $dbpass='JubjubBird1806!';
  $basepath='';
  $dbname='phpmyadmin';
  $dbserver='az304-mysql-srv.mysql.database.azure.com';
  $dbport='3306';
  $dbtype='mysql';
?>
